
# WeWeb dLocal Backend

Este backend permite procesar pagos con dLocal y conectarse a Supabase.

## Instalación
1. Clonar el repositorio
2. Instalar dependencias:
   ```bash
   npm install
   ```
3. Copiar `.env.example` a `.env` y configurar variables.

## Ejecución
```bash
npm start
```
